# Task 7 — Basic Sales Summary (SQLite + Python)

This repository contains a tiny SQLite database, a Python script that runs 1–2 SQL queries, prints the results, and renders a simple bar chart using matplotlib.

## Files
- `sales_data.db` — SQLite database with a single table `sales`
- `task7_sales_summary.py` — Python script connecting to the DB, running SQL, printing results, and plotting a bar chart
- `sales_chart.png` — Bar chart output (revenue by product)
- `sales_summary_output.txt` — Plain-text printout captured from the analysis run

## How to Run
1. Ensure you have Python 3 with `pandas` and `matplotlib` installed.
2. Place `task7_sales_summary.py` and `sales_data.db` in the same folder.
3. Run:
   ```bash
   python task7_sales_summary.py
   ```
4. The script will print a table (product, total_qty, revenue), show a bar chart, and save `sales_chart.png`.

## SQL Used
```sql
SELECT 
  product, 
  SUM(quantity) AS total_qty, 
  ROUND(SUM(quantity * price), 2) AS revenue
FROM sales
GROUP BY product
ORDER BY revenue DESC;
```

## What You’ll Learn
- Connecting Python to SQLite with `sqlite3`
- Running basic aggregation queries with `GROUP BY`
- Calculating revenue as `SUM(quantity * price)`
- Loading query results into pandas and plotting with matplotlib

## Interview Prep (Quick Answers)
- **How did you connect Python to a database?** Using `sqlite3.connect("sales_data.db")`.
- **What SQL query did you run?** See the SQL above; aggregates quantity and revenue grouped by product.
- **What does `GROUP BY` do?** It groups rows by a column so aggregate functions (SUM, COUNT) apply per group.
- **How did you calculate revenue?** `SUM(quantity * price)`.
- **How did you visualize the result?** Bar chart in matplotlib.
- **What does pandas do?** Loads SQL results into a DataFrame for easy printing and plotting.
- **Benefit of SQL inside Python?** Combine DB speed for aggregation with Python’s analysis/visualization ecosystem.

---

*Generated: 2025-08-17 08:01:45*