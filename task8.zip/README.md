
# Sales Dashboard - Internship Task 8

## Objective
To design a basic interactive dashboard showing sales performance by product category, region, and month.

## Dataset
- **File Used:** Superstore_Sales_Clean.csv
- **Columns:** Order Date, Region, Category, Sales, Profit, Month-Year

## Tools Used
- **Python + Pandas** for data cleaning and preprocessing
- **Power BI** for dashboard creation

## Dashboard Visuals
1. **Line Chart** – Sales over Months
2. **Bar Chart** – Sales by Region
3. **Donut Chart** – Sales by Category
4. **Slicer/Filter** – Region

## Key Insights
1. **West Region** showed the highest sales overall, especially in Q3.
2. **Technology Category** contributed the largest portion of total sales compared to Furniture and Office Supplies.
3. **Monthly Sales** displayed a steady growth trend over the year.
4. **South Region** had the lowest sales but showed improvement towards year-end.

## Files Included
- `Superstore_Sales_Clean.csv` – Cleaned dataset ready for Power BI
- `README.md` – Explanation and insights

## How to Use
1. Import `Superstore_Sales_Clean.csv` into Power BI.
2. Create visuals as per the above steps.
3. Export dashboard as PDF/Screenshot for submission.

---
✅ This completes **Task 8: Simple Sales Dashboard Design** for the internship.
